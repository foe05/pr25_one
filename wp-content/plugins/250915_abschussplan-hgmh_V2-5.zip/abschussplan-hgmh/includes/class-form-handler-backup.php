BACKUP of class-form-handler.php before fixing fatal error on activation
