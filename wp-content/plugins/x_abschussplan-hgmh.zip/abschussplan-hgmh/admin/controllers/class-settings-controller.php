<?php
/**
 * Settings Controller - Manages plugin settings
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class AHGMH_Settings_Controller {
    
    private $wildart_controller;
    
    public function __construct() {
        $this->wildart_controller = new AHGMH_Wildart_Controller();
    }
    
    /**
     * Render master data management (Jagdbezirke & Meldegruppen)
     */
    public function render_master_data() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        $database = abschussplan_hgmh()->database;
        
        // Handle Migration
        $migration_message = '';
        if (isset($_POST['ahgmh_migrate_legacy']) && check_admin_referer('ahgmh_migrate_legacy_nonce')) {
            $count = $database->migrate_legacy_jagdbezirke();
            $migration_message = '<div class="notice notice-success is-dismissible"><p>' . sprintf(esc_html__('Migration erfolgreich. %d Jagdbezirke wurden übernommen.', 'abschussplan-hgmh'), $count) . '</p></div>';
        }
        
        // Get all jagdbezirke
        $jagdbezirke = $database->get_all_jagdbezirke();
        
        ?>
        <div class="wrap ahgmh-admin-modern">
            <h1 class="ahgmh-page-title">
                <span class="dashicons dashicons-palmtree"></span>
                <?php echo esc_html__('Stammdaten', 'abschussplan-hgmh'); ?>
            </h1>
            
            <?php echo $migration_message; ?>
            
            <div class="notice notice-info inline">
                <p><?php echo esc_html__('Hier verwalten Sie Jagdbezirke und Meldegruppen.', 'abschussplan-hgmh'); ?></p>
            </div>
            
            <!-- Migration Tool -->
            <div class="card">
                <h2><?php echo esc_html__('Datenbank-Migration', 'abschussplan-hgmh'); ?></h2>
                <p><?php echo esc_html__('Falls Sie von einer älteren Version kommen und keine Jagdbezirke sehen, können Sie hier die alten Daten importieren.', 'abschussplan-hgmh'); ?></p>
                <form method="post" action="">
                    <?php wp_nonce_field('ahgmh_migrate_legacy_nonce'); ?>
                    <input type="hidden" name="ahgmh_migrate_legacy" value="1">
                    <?php submit_button(__('Alte Jagdbezirke migrieren', 'abschussplan-hgmh'), 'secondary'); ?>
                </form>
            </div>
            
            <!-- Jagdbezirk management table -->
            <div class="card" style="margin-top: 20px;">
                <h2><?php echo esc_html__('Jagdbezirke', 'abschussplan-hgmh'); ?></h2>
                
                <?php if (empty($jagdbezirke)): ?>
                    <p><em><?php echo esc_html__('Keine Jagdbezirke gefunden.', 'abschussplan-hgmh'); ?></em></p>
                <?php else: ?>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th><?php echo esc_html__('Wildart', 'abschussplan-hgmh'); ?></th>
                                <th><?php echo esc_html__('Meldegruppe', 'abschussplan-hgmh'); ?></th>
                                <th><?php echo esc_html__('Jagdbezirk', 'abschussplan-hgmh'); ?></th>
                                <th><?php echo esc_html__('Status', 'abschussplan-hgmh'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($jagdbezirke as $bezirk): ?>
                                <tr>
                                    <td><?php echo esc_html($bezirk['wildart']); ?></td>
                                    <td><?php echo esc_html($bezirk['meldegruppe']); ?></td>
                                    <td><?php echo esc_html($bezirk['jagdbezirk']); ?></td>
                                    <td>
                                        <?php if ($bezirk['active']): ?>
                                            <span class="dashicons dashicons-yes" style="color: green;"></span>
                                        <?php else: ?>
                                            <span class="dashicons dashicons-no" style="color: red;"></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render user management (Obleute)
     */
    public function render_user_management() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        // Handle form submission
        $message = '';
        if (isset($_POST['ahgmh_assign_user']) && check_admin_referer('ahgmh_assign_user_nonce')) {
            $user_id = intval($_POST['user_id']);
            $wildart = sanitize_text_field($_POST['wildart']);
            $meldegruppe = sanitize_text_field($_POST['meldegruppe']);
            
            if (AHGMH_Permissions_Service::assign_user_to_meldegruppe($user_id, $wildart, $meldegruppe)) {
                $message = '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Zuweisung erfolgreich gespeichert.', 'abschussplan-hgmh') . '</p></div>';
            } else {
                $message = '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Fehler bei der Zuweisung.', 'abschussplan-hgmh') . '</p></div>';
            }
        }
        
        if (isset($_POST['ahgmh_remove_assignment']) && check_admin_referer('ahgmh_remove_assignment_nonce')) {
            $user_id = intval($_POST['user_id']);
            $wildart = sanitize_text_field($_POST['wildart']);
            
            if (AHGMH_Permissions_Service::remove_user_assignment($user_id, $wildart)) {
                $message = '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Zuweisung erfolgreich entfernt.', 'abschussplan-hgmh') . '</p></div>';
            } else {
                $message = '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Fehler beim Entfernen.', 'abschussplan-hgmh') . '</p></div>';
            }
        }
        
        $users = get_users(array('orderby' => 'display_name'));
        $species = get_option('ahgmh_species', array('Rotwild', 'Damwild'));
        
        ?>
        <div class="wrap ahgmh-admin-modern">
            <h1 class="ahgmh-page-title">
                <span class="dashicons dashicons-groups"></span>
                <?php echo esc_html__('Obleute verwalten', 'abschussplan-hgmh'); ?>
            </h1>
            
            <?php echo $message; ?>
            
            <div class="card">
                <h2><?php echo esc_html__('Neue Zuweisung', 'abschussplan-hgmh'); ?></h2>
                <form method="post" action="">
                    <?php wp_nonce_field('ahgmh_assign_user_nonce'); ?>
                    <input type="hidden" name="ahgmh_assign_user" value="1">
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="user_id"><?php echo esc_html__('Benutzer', 'abschussplan-hgmh'); ?></label></th>
                            <td>
                                <select name="user_id" id="user_id" required class="regular-text">
                                    <option value=""><?php echo esc_html__('Benutzer wählen...', 'abschussplan-hgmh'); ?></option>
                                    <?php foreach ($users as $user): ?>
                                        <option value="<?php echo esc_attr($user->ID); ?>"><?php echo esc_html($user->display_name . ' (' . $user->user_login . ')'); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wildart"><?php echo esc_html__('Wildart', 'abschussplan-hgmh'); ?></label></th>
                            <td>
                                <select name="wildart" id="wildart" required class="regular-text">
                                    <option value=""><?php echo esc_html__('Wildart wählen...', 'abschussplan-hgmh'); ?></option>
                                    <?php foreach ($species as $s): ?>
                                        <option value="<?php echo esc_attr($s); ?>"><?php echo esc_html($s); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="meldegruppe"><?php echo esc_html__('Meldegruppe', 'abschussplan-hgmh'); ?></label></th>
                            <td>
                                <input type="text" name="meldegruppe" id="meldegruppe" required class="regular-text" placeholder="z.B. Gruppe A">
                                <p class="description"><?php echo esc_html__('Exakter Name der Meldegruppe.', 'abschussplan-hgmh'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <?php submit_button(__('Zuweisen', 'abschussplan-hgmh')); ?>
                </form>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2><?php echo esc_html__('Bestehende Zuweisungen', 'abschussplan-hgmh'); ?></h2>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Benutzer', 'abschussplan-hgmh'); ?></th>
                            <th><?php echo esc_html__('Wildart', 'abschussplan-hgmh'); ?></th>
                            <th><?php echo esc_html__('Meldegruppe', 'abschussplan-hgmh'); ?></th>
                            <th><?php echo esc_html__('Aktionen', 'abschussplan-hgmh'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $has_assignments = false;
                        foreach ($users as $user) {
                            $assignments = AHGMH_Permissions_Service::get_user_assignments($user->ID);
                            if (!empty($assignments)) {
                                $has_assignments = true;
                                foreach ($assignments as $wildart => $meldegruppe) {
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html($user->display_name); ?></td>
                                        <td><?php echo esc_html($wildart); ?></td>
                                        <td><?php echo esc_html($meldegruppe); ?></td>
                                        <td>
                                            <form method="post" action="" style="display:inline;">
                                                <?php wp_nonce_field('ahgmh_remove_assignment_nonce'); ?>
                                                <input type="hidden" name="ahgmh_remove_assignment" value="1">
                                                <input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>">
                                                <input type="hidden" name="wildart" value="<?php echo esc_attr($wildart); ?>">
                                                <button type="submit" class="button button-small button-link-delete" onclick="return confirm('Wirklich löschen?')"><?php echo esc_html__('Entfernen', 'abschussplan-hgmh'); ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                        }
                        
                        if (!$has_assignments) {
                            echo '<tr><td colspan="4">' . esc_html__('Keine Zuweisungen gefunden.', 'abschussplan-hgmh') . '</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        ?>
        <div class="wrap ahgmh-admin-modern">
            <h1 class="ahgmh-page-title">
                <span class="dashicons dashicons-admin-settings"></span>
                <?php echo esc_html__('Einstellungen', 'abschussplan-hgmh'); ?>
            </h1>
            
            <div class="ahgmh-settings-tabs">
                <nav class="nav-tab-wrapper">
                    <a href="#wildart-config" class="nav-tab nav-tab-active"><?php echo esc_html__('Wildarten-Konfiguration', 'abschussplan-hgmh'); ?></a>
                    <a href="#general" class="nav-tab"><?php echo esc_html__('Allgemein', 'abschussplan-hgmh'); ?></a>
                    <a href="#export" class="nav-tab"><?php echo esc_html__('Export', 'abschussplan-hgmh'); ?></a>
                </nav>
                
                <div id="wildart-config" class="ahgmh-tab-content">
                    <?php echo $this->wildart_controller->render_config_section(); ?>
                </div>
                
                <div id="general" class="ahgmh-tab-content" style="display: none;">
                    <h2><?php echo esc_html__('Allgemeine Einstellungen', 'abschussplan-hgmh'); ?></h2>
                    <p><?php echo esc_html__('Hier können allgemeine Plugin-Einstellungen konfiguriert werden.', 'abschussplan-hgmh'); ?></p>
                </div>
                
                <div id="export" class="ahgmh-tab-content" style="display: none;">
                    <h2><?php echo esc_html__('Export-Einstellungen', 'abschussplan-hgmh'); ?></h2>
                    <p><?php echo esc_html__('Export-Konfiguration für CSV und Excel-Dateien.', 'abschussplan-hgmh'); ?></p>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('.nav-tab').on('click', function(e) {
                e.preventDefault();
                
                // Update tabs
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                // Show content
                $('.ahgmh-tab-content').hide();
                $($(this).attr('href')).show();
            });
        });
        </script>
        <?php
    }
}
