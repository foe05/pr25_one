<?php
/**
 * Wildart Service Class
 * Business logic for wildart operations
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Wildart Service for business logic
 */
class AHGMH_Wildart_Service {
    
    /**
     * Get all wildarten
     */
    public function get_all_wildarten() {
        $species = get_option('ahgmh_species', ['Rotwild', 'Damwild', 'Rehwild']);
        return AHGMH_Validation_Service::sanitize_text_array($species);
    }
    
    /**
     * Create new wildart
     */
    public function create_wildart($name) {
        $name = AHGMH_Validation_Service::validate_species_name($name);
        if (!$name) {
            throw new Exception('Ungültiger Wildart-Name');
        }
        
        $species = $this->get_all_wildarten();
        
        if (in_array($name, $species, true)) {
            throw new Exception('Wildart existiert bereits');
        }
        
        $species[] = $name;
        update_option('ahgmh_species', $species);
        
        // Initialize default meldegruppen for new wildart
        $this->initialize_default_meldegruppen($name);
        
        return ['species' => $species, 'created' => $name];
    }
    
    /**
     * Delete wildart
     */
    public function delete_wildart($wildart) {
        $species = $this->get_all_wildarten();
        $key = array_search($wildart, $species, true);  // Use strict comparison
        
        if ($key === false) {
            throw new Exception('Wildart nicht gefunden');
        }
        
        unset($species[$key]);
        $species = array_values($species);
        update_option('ahgmh_species', $species);
        
        // Clean up related data
        $this->cleanup_wildart_data($wildart);
        
        return ['species' => $species, 'deleted' => $wildart];
    }
    
    /**
     * Get wildart configuration
     */
    public function get_wildart_config($wildart) {
        return [
            'categories' => $this->get_categories($wildart),
            'meldegruppen' => $this->get_meldegruppen($wildart),
            'limit_mode' => $this->get_limit_mode($wildart),
            'limits' => $this->get_limits($wildart)
        ];
    }
    
    /**
     * Get categories for wildart
     */
    public function get_categories($wildart) {
        // Use legacy option key format: ahgmh_categories_{wildart}
        $key = 'ahgmh_categories_' . sanitize_key($wildart);
        $categories = get_option($key, []);
        
        if (!empty($categories)) {
            return AHGMH_Validation_Service::sanitize_text_array($categories);
        }
        
        // Return default categories if nothing saved yet
        return $this->get_default_categories($wildart);
    }
    
    /**
     * Save categories for wildart
     */
    public function save_categories($wildart, $categories) {
        $categories = AHGMH_Validation_Service::sanitize_text_array($categories);
        
        // Use legacy option key format
        $key = 'ahgmh_categories_' . sanitize_key($wildart);
        update_option($key, $categories);
        
        // Also update the 'ahgmh_categories' option which seems to be a global list of all categories?
        // Legacy code in Form_Handler::save_categories used 'ahgmh_categories'. 
        // We might need to maintain that if it's used for dropdowns across species?
        // Checking Form_Handler::render_admin (old) it merges all categories.
        // So we don't strictly need to update the global list if we iterate species.
    }
    
    /**
     * Get meldegruppen for wildart
     */
    public function get_meldegruppen($wildart) {
        // New structure: ahgmh_wildart_meldegruppen option (array of wildart => meldegruppen)
        $meldegruppen = get_option('ahgmh_wildart_meldegruppen', []);
        
        if (isset($meldegruppen[$wildart]) && !empty($meldegruppen[$wildart])) {
            return AHGMH_Validation_Service::sanitize_text_array($meldegruppen[$wildart]);
        }
        
        // Fallback: check if there are legacy meldegruppen configs?
        // The legacy system used `ahgmh_meldegruppen_config` table.
        // But for the simple list, we can just default or migrate if needed.
        // Since we just migrated, we might rely on the new option if we filled it?
        // Wait, did we fill 'ahgmh_wildart_meldegruppen'?
        // If not, we should probably read from the database table we just migrated to!
        
        // Use DB handler to get meldegruppen from the new clean table
        $db = new AHGMH_Database_Handler();
        $jagdbezirke = $db->get_all_jagdbezirke();
        
        $found_meldegruppen = [];
        foreach ($jagdbezirke as $row) {
            if ($row['wildart'] == $wildart) {
                $found_meldegruppen[] = $row['meldegruppe'];
            }
        }
        
        if (!empty($found_meldegruppen)) {
            return array_values(array_unique($found_meldegruppen));
        }
        
        // Final fallback
        return ['Gruppe_A', 'Gruppe_B'];
    }
    
    /**
     * Save meldegruppen for wildart
     */
    public function save_meldegruppen($wildart, $meldegruppen) {
        $meldegruppen = AHGMH_Validation_Service::sanitize_text_array($meldegruppen);
        $meldegruppen = array_filter($meldegruppen); // Remove empty
        
        // Save to ahgmh_wildart_meldegruppen option
        $wildart_meldegruppen = get_option('ahgmh_wildart_meldegruppen', []);
        $wildart_meldegruppen[$wildart] = array_values($meldegruppen);
        update_option('ahgmh_wildart_meldegruppen', $wildart_meldegruppen);
        
        // Also update global list
        $this->update_global_meldegruppen_list();
    }
    
    /**
     * Get limits for wildart
     * Returns structure: ['gesamt' => [cat => val], 'MeldegruppeX' => [cat => val]]
     */
    public function get_limits($wildart) {
        $limits = [];
        
        // 1. Get Legacy Total Limits (Hegegemeinschaft Total)
        // Key: abschuss_category_limits_{wildart}
        $total_key = 'abschuss_category_limits_' . sanitize_key($wildart);
        $total_limits = get_option($total_key, []);
        $limits['gesamt'] = $total_limits;
        
        // 2. Get Meldegruppen specific limits (if any exist in new structure)
        // We might have stored them in 'ahgmh_wildart_limits' option during this refactor?
        $new_limits_opt = get_option('ahgmh_wildart_limits', []);
        if (isset($new_limits_opt[$wildart])) {
            // Merge new limits, but prefer legacy total limits for 'gesamt' key to ensure data integrity
            $saved_limits = $new_limits_opt[$wildart];
            if (isset($saved_limits['gesamt'])) {
                unset($saved_limits['gesamt']); // Use the one from legacy key
            }
            $limits = array_merge($limits, $saved_limits);
        }
        
        return $limits;
    }
    
    /**
     * Save limits for wildart
     */
    public function save_limits($wildart, $limits) {
        // 1. Save 'gesamt' limits to legacy option
        if (isset($limits['gesamt'])) {
            $total_key = 'abschuss_category_limits_' . sanitize_key($wildart);
            update_option($total_key, $limits['gesamt']);
        }
        
        // 2. Save full structure to new option 'ahgmh_wildart_limits' for meldegruppen support
        $wildart_limits = get_option('ahgmh_wildart_limits', []);
        $wildart_limits[$wildart] = $limits;
        update_option('ahgmh_wildart_limits', $wildart_limits);
    }
    
    /**
     * Get default categories for a species
     */
    private function get_default_categories($species) {
        $defaults = [
            'Rotwild' => [
                'Wildkalb (AK0)', 'Schmaltier (AK 1)', 'Alttier (AK 2)',
                'Hirschkalb (AK 0)', 'Schmalspießer (AK1)', 'Junger Hirsch (AK 2)',
                'Mittelalter Hirsch (AK 3)', 'Alter Hirsch (AK 4)'
            ],
            'Damwild' => [
                'Wildkalb (AK0)', 'Schmaltier (AK 1)', 'Alttier (AK 2)',
                'Hirschkalb (AK 0)', 'Schmalspießer (AK1)', 'Junger Hirsch (AK 2)',
                'Mittelalter Hirsch (AK 3)', 'Alter Hirsch (AK 4)'
            ],
            'Rehwild' => [
                'Rehkitz', 'Rehgeiß', 'Rehbock'
            ]
        ];
        
        return isset($defaults[$species]) ? $defaults[$species] : [];
    }
    
    /**
     * Clean up wildart-related data when deleting
     */
    private function cleanup_wildart_data($wildart) {
        // Remove from categories
        $categories = get_option('ahgmh_wildart_categories', []);
        unset($categories[$wildart]);
        update_option('ahgmh_wildart_categories', $categories);
        
        // Remove from meldegruppen
        $meldegruppen = get_option('ahgmh_wildart_meldegruppen', []);
        unset($meldegruppen[$wildart]);
        update_option('ahgmh_wildart_meldegruppen', $meldegruppen);
        
        // Remove from limits
        $limits = get_option('ahgmh_wildart_limits', []);
        unset($limits[$wildart]);
        update_option('ahgmh_wildart_limits', $limits);
        
        // Remove from limit modes
        $modes = get_option('ahgmh_limit_modes', []);
        unset($modes[$wildart]);
        update_option('ahgmh_limit_modes', $modes);
    }
}
