(function ($) {
    'use strict';

    /**
     * Initialize admin functionality
     */
    function initAdmin() {
        initQuickActions();
        initTabSwitching();
        initTooltips();
        initProgressAnimations();
        initAutoRefresh();
        initWildartConfig();
        initObmannManagement();
        initShortcodeCopy();
        initBulkActions();
    }

    // Initialize on document ready
    $(document).ready(function () {
        initAdmin();
    });

    /**
     * Initialize quick actions
     */
    function initQuickActions() {
        // Quick CSV export - Fixed selector
        $(document).on('click', '#quick-export', function (e) {
            e.preventDefault();
            handleQuickExport($(this));
        });

        // Export buttons in tables
        $(document).on('click', '.ahgmh-export-btn', function (e) {
            e.preventDefault();
            var species = $(this).data('species') || '';
            var format = $(this).data('format') || 'csv';
            handleQuickExport($(this), species, format);
        });

        // Quick refresh
        $('.ahgmh-quick-refresh').on('click', function (e) {
            e.preventDefault();
            location.reload();
        });

        // Delete submission buttons
        $(document).on('click', '.ahgmh-delete-submission', function(e) {
            e.preventDefault();
            const id = $(this).data('id');
            const nonce = $(this).data('nonce');
            
            if (confirm('Diese Meldung wirklich löschen?')) {
                handleDeleteSubmission(id, nonce, $(this));
            }
        });

        // Edit submission buttons  
        $(document).on('click', '.ahgmh-edit-submission', function(e) {
            e.preventDefault();
            const $button = $(this);
            
            // Prevent multiple clicks
            if ($button.prop('disabled')) return;
            
            // Check if edit form already exists
            if ($button.closest('tr').next('.ahgmh-edit-submission-container').length > 0) {
                return;
            }
            
            const id = $button.data('id');
            handleEditSubmission(id, $button);
        });
    }

    /**
     * Handle quick CSV export
     */
    function handleQuickExport($button, species, format) {
        species = species || '';
        format = format || 'csv';

        const originalText = $button.text();
        $button.prop('disabled', true).text('Exportiere...');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_quick_export',
                nonce: ahgmh_admin.nonce,
                species: species,
                format: format
            },
            success: function (response) {
                if (response.success && response.data.download_url) {
                    // Create temporary download link
                    var link = document.createElement('a');
                    link.href = response.data.download_url;
                    link.download = response.data.filename || 'export.csv';
                    link.style.display = 'none';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                    showNotification('CSV Export erfolgreich!', 'success');
                } else {
                    var errorMsg = response.data && response.data.message ? response.data.message : (response.data || 'Unbekannter Fehler');
                    showNotification('Fehler beim CSV Export: ' + errorMsg, 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim CSV Export.', 'error');
            },
            complete: function () {
                $button.prop('disabled', false).text(originalText);
            }
        });
    }

    /**
     * Handle delete submission
     */
    function handleDeleteSubmission(id, nonce, $button) {
        const $row = $button.closest('tr');
        
        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_delete_submission',
                id: id,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    $row.fadeOut(300, function() {
                        $(this).remove();
                    });
                    showNotification('Meldung gelöscht', 'success');
                } else {
                    showNotification(response.data || 'Löschen fehlgeschlagen', 'error');
                }
            },
            error: function() {
                showNotification('Löschen fehlgeschlagen', 'error');
            }
        });
    }

    /**
     * Handle edit submission - loads data via AJAX and shows improved edit form
     */
    function handleEditSubmission(id, $button) {
        const $row = $button.closest('tr');

        // Show loading state
        $button.prop('disabled', true).text('Lade...');

        // Load submission data via AJAX
        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_get_submission_data',
                id: id,
                nonce: ahgmh_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showEditForm($row, id, response.data);
                } else {
                    showNotification(response.data || 'Fehler beim Laden der Daten', 'error');
                    $button.prop('disabled', false).text('Bearbeiten');
                }
            },
            error: function() {
                showNotification('Fehler beim Laden der Daten', 'error');
                $button.prop('disabled', false).text('Bearbeiten');
            }
        });
    }

    /**
     * Show the edit form with loaded data
     */
    function showEditForm($row, id, data) {
        const submission = data.submission;
        const options = data.options;

        // Build category options
        let categoryOptions = '<option value="">-- Kategorie waehlen --</option>';
        if (options.categories && options.categories.length > 0) {
            options.categories.forEach(function(cat) {
                const selected = cat === submission.kategorie ? 'selected' : '';
                categoryOptions += `<option value="${escapeHtml(cat)}" ${selected}>${escapeHtml(cat)}</option>`;
            });
        }

        // Build jagdbezirk options
        let jagdbezirkOptions = '<option value="">-- Jagdbezirk waehlen --</option>';
        if (options.jagdbezirke && options.jagdbezirke.length > 0) {
            options.jagdbezirke.forEach(function(jb) {
                const jbName = jb.jagdbezirk || jb;
                const selected = jbName === submission.jagdbezirk ? 'selected' : '';
                jagdbezirkOptions += `<option value="${escapeHtml(jbName)}" ${selected}>${escapeHtml(jbName)}</option>`;
            });
        }

        // Build meldegruppe options
        let meldegruppeOptions = '<option value="">-- Meldegruppe waehlen --</option>';
        if (options.meldegruppen && options.meldegruppen.length > 0) {
            options.meldegruppen.forEach(function(mg) {
                const selected = mg === submission.meldegruppe ? 'selected' : '';
                meldegruppeOptions += `<option value="${escapeHtml(mg)}" ${selected}>${escapeHtml(mg)}</option>`;
            });
        }

        // Build user options
        let userOptions = '<option value="0">-- Kein Erfasser --</option>';
        if (options.users && options.users.length > 0) {
            options.users.forEach(function(user) {
                const selected = parseInt(user.id) === parseInt(submission.user_id) ? 'selected' : '';
                userOptions += `<option value="${user.id}" ${selected}>${escapeHtml(user.display_name)}</option>`;
            });
        }

        // Format date for datetime-local input
        const dateValue = convertToDateTimeLocal(submission.created_at);

        // Create improved inline edit form with 2-column layout
        const editFormHtml = `
            <td colspan="10" class="ahgmh-edit-submission-row">
                <form class="ahgmh-edit-submission-form" data-id="${id}">
                    <div class="ahgmh-edit-form-header">
                        <h3>Meldung #${id} bearbeiten</h3>
                        <span class="ahgmh-edit-form-close">&times;</span>
                    </div>
                    <div class="ahgmh-edit-form-body">
                        <div class="ahgmh-edit-form-grid">
                            <!-- Left Column -->
                            <div class="ahgmh-edit-form-column">
                                <div class="ahgmh-edit-form-group">
                                    <label>Wildart:</label>
                                    <input type="text" name="wildart" value="${escapeHtml(submission.wildart)}" class="regular-text" readonly disabled>
                                    <span class="ahgmh-field-hint">Wildart kann nicht geaendert werden</span>
                                </div>
                                <div class="ahgmh-edit-form-group">
                                    <label>Kategorie: <span class="required">*</span></label>
                                    <select name="kategorie" class="regular-text" required>
                                        ${categoryOptions}
                                    </select>
                                </div>
                                <div class="ahgmh-edit-form-group">
                                    <label>Meldegruppe:</label>
                                    <select name="meldegruppe" class="regular-text">
                                        ${meldegruppeOptions}
                                    </select>
                                </div>
                                <div class="ahgmh-edit-form-group">
                                    <label>Jagdbezirk:</label>
                                    <select name="jagdbezirk" class="regular-text">
                                        ${jagdbezirkOptions}
                                    </select>
                                </div>
                                <div class="ahgmh-edit-form-group">
                                    <label>WUS-Nummer:</label>
                                    <input type="text" name="wus_nummer" value="${escapeHtml(submission.wus_nummer || '')}" class="regular-text">
                                </div>
                            </div>
                            <!-- Right Column -->
                            <div class="ahgmh-edit-form-column">
                                <div class="ahgmh-edit-form-group">
                                    <label>Erfasser:</label>
                                    <select name="user_id" class="regular-text">
                                        ${userOptions}
                                    </select>
                                </div>
                                <div class="ahgmh-edit-form-group">
                                    <label>Erfassungsdatum:</label>
                                    <input type="datetime-local" name="datum" value="${dateValue}" class="regular-text">
                                </div>
                                <div class="ahgmh-edit-form-group">
                                    <label>Interne Notiz:</label>
                                    <textarea name="interne_notiz" class="regular-text" rows="2">${escapeHtml(submission.interne_notiz || '')}</textarea>
                                </div>
                                <div class="ahgmh-edit-form-group">
                                    <label>Bemerkung:</label>
                                    <textarea name="bemerkung" class="regular-text" rows="2">${escapeHtml(submission.bemerkung || '')}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ahgmh-edit-form-footer">
                        <button type="button" class="button button-secondary ahgmh-cancel-edit-submission">Abbrechen</button>
                        <button type="submit" class="button button-primary">Speichern</button>
                    </div>
                </form>
            </td>
        `;

        // Hide current row and show edit form
        $row.hide().after(`<tr class="ahgmh-edit-submission-container">${editFormHtml}</tr>`);

        // Get the newly created form element and add event handlers
        const $editRow = $('.ahgmh-edit-submission-container').last();
        const $editForm = $editRow.find('.ahgmh-edit-submission-form');

        // Handle form submission
        $editForm.on('submit', function(e) {
            e.preventDefault();

            const $form = $(this);
            const $submitBtn = $form.find('button[type="submit"]');

            // Prevent multiple submissions
            if ($submitBtn.prop('disabled')) {
                return false;
            }

            $submitBtn.prop('disabled', true).text('Speichere...');

            const formData = {
                action: 'ahgmh_edit_submission',
                id: id,
                nonce: ahgmh_admin.nonce,
                wildart: submission.wildart, // Keep original wildart
                kategorie: $form.find('select[name="kategorie"]').val(),
                wus_nummer: $form.find('input[name="wus_nummer"]').val(),
                interne_notiz: $form.find('textarea[name="interne_notiz"]').val(),
                bemerkung: $form.find('textarea[name="bemerkung"]').val(),
                jagdbezirk: $form.find('select[name="jagdbezirk"]').val(),
                datum: $form.find('input[name="datum"]').val(),
                user_id: $form.find('select[name="user_id"]').val()
            };

            $.ajax({
                url: ahgmh_admin.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        showNotification('Meldung aktualisiert', 'success');
                        // Refresh page to show updated data
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        const errorMsg = response.data || 'Speichern fehlgeschlagen';
                        showNotification(errorMsg, 'error');
                        $submitBtn.prop('disabled', false).text('Speichern');
                    }
                },
                error: function() {
                    showNotification('Speichern fehlgeschlagen - Netzwerkfehler', 'error');
                    $submitBtn.prop('disabled', false).text('Speichern');
                }
            });
        });

        // Handle cancel button and close icon
        $editRow.find('.ahgmh-cancel-edit-submission, .ahgmh-edit-form-close').on('click', function() {
            $editRow.remove();
            $row.show();
            $row.find('.ahgmh-edit-submission').prop('disabled', false).text('Bearbeiten');
        });

        // Handle meldegruppe change to filter jagdbezirke
        $editRow.find('select[name="meldegruppe"]').on('change', function() {
            const selectedMeldegruppe = $(this).val();
            const $jagdbezirkSelect = $editRow.find('select[name="jagdbezirk"]');

            if (selectedMeldegruppe) {
                // Load jagdbezirke filtered by meldegruppe (using admin endpoint)
                $.ajax({
                    url: ahgmh_admin.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'ahgmh_admin_get_jagdbezirke_by_meldegruppe',
                        meldegruppe: selectedMeldegruppe,
                        nonce: ahgmh_admin.nonce
                    },
                    success: function(response) {
                        if (response.success && response.data) {
                            let newOptions = '<option value="">-- Jagdbezirk waehlen --</option>';
                            response.data.forEach(function(jb) {
                                const jbName = jb.jagdbezirk || jb;
                                newOptions += `<option value="${escapeHtml(jbName)}">${escapeHtml(jbName)}</option>`;
                            });
                            $jagdbezirkSelect.html(newOptions);
                        }
                    }
                });
            }
        });
    }

    /**
     * Helper function to escape HTML
     */
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Helper function to convert date string to datetime-local format
     * Supports both German format (23.12.2024 14:30) and MySQL format (2024-12-23 14:30:00)
     */
    function convertToDateTimeLocal(dateStr) {
        if (!dateStr || dateStr.trim() === '') return '';

        try {
            dateStr = dateStr.trim();

            // Check if MySQL format (YYYY-MM-DD HH:MM:SS)
            if (dateStr.match(/^\d{4}-\d{2}-\d{2}/)) {
                const parts = dateStr.split(' ');
                if (parts.length >= 2) {
                    const datePart = parts[0];
                    const timePart = parts[1].substring(0, 5); // Take only HH:MM
                    return `${datePart}T${timePart}`;
                }
                return dateStr.substring(0, 10) + 'T00:00';
            }

            // German format (DD.MM.YYYY HH:MM)
            const parts = dateStr.split(' ');
            if (parts.length !== 2) return '';

            const dateParts = parts[0].split('.');
            const timeParts = parts[1].split(':');

            if (dateParts.length !== 3 || timeParts.length < 2) return '';

            // Format: YYYY-MM-DDTHH:MM
            return `${dateParts[2]}-${dateParts[1].padStart(2, '0')}-${dateParts[0].padStart(2, '0')}T${timeParts[0].padStart(2, '0')}:${timeParts[1].padStart(2, '0')}`;
        } catch (error) {
            console.error('Date conversion error:', error);
            return '';
        }
    }

    /**
     * Initialize tab switching
     */
    function initTabSwitching() {
        $('.ahgmh-tab').on('click', function (e) {
            // Let natural link navigation handle tab switching
            // This is just for visual feedback
            $('.ahgmh-tab').removeClass('active');
            $(this).addClass('active');
        });
    }

    /**
     * Initialize tooltips
     */
    function initTooltips() {
        $('[title]').each(function () {
            $(this).attr('data-title', $(this).attr('title'));
            $(this).removeAttr('title');
        });

        $('[data-title]').hover(
            function () {
                const title = $(this).attr('data-title');
                const tooltip = $('<div class="ahgmh-tooltip">' + title + '</div>');
                $('body').append(tooltip);

                const pos = $(this).offset();
                tooltip.css({
                    top: pos.top - tooltip.outerHeight() - 10,
                    left: pos.left + ($(this).outerWidth() / 2) - (tooltip.outerWidth() / 2)
                });
            },
            function () {
                $('.ahgmh-tooltip').remove();
            }
        );
    }

    /**
     * Initialize progress animations
     */
    function initProgressAnimations() {
        $('.progress-fill, .ahgmh-progress-bar').each(function () {
            const $bar = $(this);
            const targetWidth = $bar.attr('data-width') || $bar.data('width');

            if (targetWidth) {
                setTimeout(function () {
                    $bar.css('width', targetWidth + (targetWidth.toString().indexOf('%') > -1 ? '' : '%'));
                }, 500);
            }
        });
    }

    /**
     * Initialize auto refresh
     */
    function initAutoRefresh() {
        // Only enable auto-refresh on dashboard
        if ($('.ahgmh-dashboard').length > 0) {
            setInterval(function () {
                $('.ahgmh-stat-number').each(function () {
                    const $stat = $(this);
                    const currentValue = parseInt($stat.text());
                    // Simulate slight updates (this would normally come from AJAX)
                    animateNumber($stat, currentValue, currentValue);
                });
            }, 60000); // Every minute
        }
    }

    /**
     * Animate number changes
     */
    function animateNumber($element, start, end) {
        const duration = 1000;
        const startTime = Date.now();

        function update() {
            const now = Date.now();
            const progress = Math.min((now - startTime) / duration, 1);
            const value = Math.floor(start + (end - start) * progress);

            $element.text(value);

            if (progress < 1) {
                requestAnimationFrame(update);
            }
        }

        update();
    }

    /**
     * Initialize Wildart Configuration (Master-Detail UI)
     */
    function initWildartConfig() {
        if ($('.ahgmh-wildart-config').length === 0) return;

        // Initialize sortable on wildart list
        initWildartSortable();

        // Create new wildart
        $(document).on('click', '#add-new-wildart', function (e) {
            e.preventDefault();
            var name = prompt('Name der neuen Wildart:');
            if (name && name.trim()) {
                createWildart(name.trim());
            }
        });

        // Delete wildart
        $(document).on('click', '.wildart-delete', function (e) {
            e.preventDefault();
            var wildart = $(this).data('wildart');
            if (confirm('Wildart "' + wildart + '" wirklich löschen?')) {
                deleteWildart(wildart);
            }
        });

        // Wildart navigation
        $(document).on('click', '.wildart-item', function (e) {
            e.preventDefault();
            var wildart = $(this).data('wildart');
            $('.wildart-item').removeClass('active');
            $(this).addClass('active');
            loadWildartConfig(wildart);
        });

        // Save categories
        $(document).on('click', '.save-categories', function (e) {
            e.preventDefault();
            var wildart = $(this).data('wildart');
            saveWildartCategories(wildart);
        });

        // Save meldegruppen
        $(document).on('click', '.save-meldegruppen', function (e) {
            e.preventDefault();
            console.log('Save meldegruppen button clicked!');
            var wildart = $(this).data('wildart');
            console.log('Wildart:', wildart);
            saveWildartMeldegruppen(wildart);
        });

        // Toggle limit mode
        $(document).on('change', '.limit-mode-radio', function () {
            var wildart = $(this).data('wildart');
            var mode = $(this).val();
            toggleLimitMode(wildart, mode);
        });

        // Save limits
        $(document).on('click', '.save-limits-btn', function (e) {
            e.preventDefault();
            var wildart = $(this).data('wildart');
            saveLimits(wildart);
        });

        // Update totals when individual limits change + validate
        $(document).on('input', '.limit-input, .total-limit-input', function () {
            updateGesamt();
            validateLimitInputs();
        });

        // Category CRUD handlers
        $(document).on('click', '#add-category', function (e) {
            e.preventDefault();
            var newCategoryValue = $('#new-category-input').val().trim();
            if (newCategoryValue) {
                var newCategoryHtml = '<div class="config-item">' +
                    '<input type="text" value="' + newCategoryValue + '" class="category-input" data-original="' + newCategoryValue + '">' +
                    '<button type="button" class="remove-item" data-type="category" data-value="' + newCategoryValue + '">' +
                    '<span class="dashicons dashicons-trash"></span>' +
                    '</button>' +
                    '</div>';
                $('#categories-list').append(newCategoryHtml);
                $('#new-category-input').val('');
            }
        });

        // Remove category handler
        $(document).on('click', '.remove-item[data-type="category"]', function (e) {
            e.preventDefault();
            $(this).closest('.config-item').remove();
        });

        // Meldegruppe CRUD handlers
        $(document).on('click', '#add-meldegruppe', function (e) {
            e.preventDefault();
            var newMeldegruppeValue = $('#new-meldegruppe-input').val().trim();
            if (newMeldegruppeValue) {
                var newMeldegruppeHtml = '<div class="config-item">' +
                    '<input type="text" value="' + newMeldegruppeValue + '" class="meldegruppe-input" data-original="' + newMeldegruppeValue + '">' +
                    '<button type="button" class="remove-item" data-type="meldegruppe" data-value="' + newMeldegruppeValue + '">' +
                    '<span class="dashicons dashicons-trash"></span>' +
                    '</button>' +
                    '</div>';
                $('#meldegruppen-list').append(newMeldegruppeHtml);
                $('#new-meldegruppe-input').val('');
            }
        });

        // Remove meldegruppe handler
        $(document).on('click', '.remove-item[data-type="meldegruppe"]', function (e) {
            e.preventDefault();
            $(this).closest('.config-item').remove();
        });

        // Enter key support for add inputs
        $(document).on('keypress', '#new-category-input', function (e) {
            if (e.which === 13) {
                $('#add-category').click();
            }
        });

        $(document).on('keypress', '#new-meldegruppe-input', function (e) {
            if (e.which === 13) {
                $('#add-meldegruppe').click();
            }
        });

        // Load first wildart if available
        var firstWildart = $('.wildart-item').first();
        if (firstWildart.length > 0) {
            firstWildart.click();
        }
    }

    /**
     * Initialize drag & drop sorting for wildart list
     */
    function initWildartSortable() {
        var $sortableList = $('#sortable-wildart-list');

        if ($sortableList.length === 0 || $('.wildart-item').length === 0) {
            return;
        }

        // Initialize jQuery UI Sortable
        $sortableList.sortable({
            items: '.wildart-item',
            handle: '.wildart-drag-handle',
            axis: 'y',
            cursor: 'move',
            opacity: 0.8,
            placeholder: 'wildart-item-placeholder',
            helper: 'clone',
            tolerance: 'pointer',
            start: function(event, ui) {
                ui.item.addClass('wildart-dragging');
                ui.placeholder.height(ui.item.height());
            },
            stop: function(event, ui) {
                ui.item.removeClass('wildart-dragging');
            },
            update: function(event, ui) {
                // Show save button when order changes
                $('#save-wildart-order').fadeIn();
            }
        });

        // Save wildart order button
        $(document).on('click', '#save-wildart-order', function(e) {
            e.preventDefault();
            saveWildartOrder();
        });
    }

    /**
     * Save wildart sort order
     */
    function saveWildartOrder() {
        var order = [];
        $('.wildart-item').each(function(index) {
            order.push($(this).data('wildart'));
        });

        var $btn = $('#save-wildart-order');
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update ahgmh-spinning"></span> Speichern...');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_save_wildart_order',
                nonce: ahgmh_admin.nonce,
                order: order
            },
            success: function(response) {
                if (response.success) {
                    showNotification('Reihenfolge gespeichert!', 'success');
                    $btn.fadeOut();

                    // Update data-order attributes
                    $('.wildart-item').each(function(index) {
                        $(this).attr('data-order', index);
                    });
                } else {
                    showNotification('Fehler beim Speichern: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function() {
                showNotification('Netzwerkfehler beim Speichern.', 'error');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    }

    /**
     * Create new wildart
     */
    function createWildart(name) {
        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_create_wildart',
                nonce: ahgmh_admin.nonce,
                name: name
            },
            success: function (response) {
                if (response.success) {
                    showNotification('Wildart erfolgreich erstellt!', 'success');
                    // Reload to show new wildart and refresh all lists
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification('Fehler beim Erstellen der Wildart: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim Erstellen der Wildart.', 'error');
            }
        });
    }

    /**
     * Delete wildart
     */
    function deleteWildart(wildart) {
        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_delete_wildart',
                nonce: ahgmh_admin.nonce,
                wildart: wildart
            },
            success: function (response) {
                if (response.success) {
                    location.reload(); // Reload to remove deleted wildart
                } else {
                    showNotification('Fehler beim Löschen der Wildart: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim Löschen der Wildart.', 'error');
            }
        });
    }

    /**
     * Load wildart configuration
     */
    function loadWildartConfig(wildart) {
        var $detailPanel = $('.ahgmh-detail-panel');
        $detailPanel.html('<div class="loading">Lade Konfiguration...</div>');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_load_wildart_config',
                nonce: ahgmh_admin.nonce,
                wildart: wildart
            },
            success: function (response) {
                if (response.success) {
                    $detailPanel.html(response.data);
                } else {
                    $detailPanel.html('<div class="error">Fehler beim Laden: ' + (response.data || 'Unbekannter Fehler') + '</div>');
                }
            },
            error: function () {
                $detailPanel.html('<div class="error">Netzwerkfehler beim Laden der Konfiguration.</div>');
            }
        });
    }

    /**
     * Save wildart categories
     */
    function saveWildartCategories(wildart) {
        var categories = [];
        $('.category-input').each(function () {
            var value = $(this).val().trim();
            if (value) {
                categories.push(value);
            }
        });

        var $btn = $('.save-categories[data-wildart="' + wildart + '"]');
        var originalText = $btn.text();
        $btn.prop('disabled', true).text('Speichern...');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_save_wildart_categories',
                nonce: ahgmh_admin.nonce,
                wildart: wildart,
                categories: categories
            },
            success: function (response) {
                if (response.success) {
                    showNotification('Kategorien gespeichert!', 'success');
                    // Reload the wildart config to update limits section
                    setTimeout(function () {
                        loadWildartConfig(wildart);
                    }, 500);
                } else {
                    showNotification('Fehler beim Speichern: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim Speichern.', 'error');
            },
            complete: function () {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    }

    /**
     * Save wildart meldegruppen
     */
    function saveWildartMeldegruppen(wildart) {
        console.log('saveWildartMeldegruppen function called for:', wildart);
        
        var meldegruppen = [];
        $('.meldegruppe-input').each(function () {
            var value = $(this).val().trim();
            if (value) {
                meldegruppen.push(value);
            }
        });
        
        console.log('Collected meldegruppen:', meldegruppen);

        var $btn = $('.save-meldegruppen[data-wildart="' + wildart + '"]');
        var originalText = $btn.text();
        $btn.prop('disabled', true).text('Speichern...');

        console.log('Starting AJAX request...');
        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_save_wildart_meldegruppen',
                nonce: ahgmh_admin.nonce,
                wildart: wildart,
                meldegruppen: meldegruppen
            },
            success: function (response) {
                if (response.success) {
                    showNotification('Meldegruppen gespeichert!', 'success');
                    // TEMP FIX: Reload entire page instead of just config
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification('Fehler beim Speichern: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim Speichern.', 'error');
            },
            complete: function () {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    }

    /**
     * Toggle limit mode and update display
     */
    function toggleLimitMode(wildart, mode) {
        // Immediately update display based on mode
        if (mode === 'meldegruppen_specific') {
            $('#meldegruppen-limits-' + wildart).show();
            $('#hegegemeinschaft-limits-' + wildart).hide();
        } else {
            $('#meldegruppen-limits-' + wildart).hide();
            $('#hegegemeinschaft-limits-' + wildart).show();
        }
        
        // Save mode to database
        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_toggle_limit_mode',
                nonce: ahgmh_admin.nonce,
                wildart: wildart,
                mode: mode
            },
            success: function (response) {
                if (response.success) {
                    showNotification('Limit-Modus geändert!', 'success');
                    // Reload the entire wildart config to rebuild limits section
                    setTimeout(function () {
                        loadWildartConfig(wildart);
                    }, 500);
                } else {
                    showNotification('Fehler beim Ändern des Modus: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim Ändern des Modus.', 'error');
            }
        });
    }

    /**
     * Update gesamt (total) calculations
     */
    function updateGesamt() {
        // Find all categories and calculate totals
        var categories = {};

        $('.limit-input').each(function () {
            var kategorie = $(this).data('kategorie');
            var value = parseInt($(this).val()) || 0;

            if (!categories[kategorie]) {
                categories[kategorie] = 0;
            }
            categories[kategorie] += value;
        });

        // Update all gesamt cells
        for (var kategorie in categories) {
            var gesamtId = 'gesamt_' + kategorie.toLowerCase().replace(/[^a-z0-9]/g, '_');
            $('#' + gesamtId).text(categories[kategorie]);
        }
    }

    /**
     * Validate all limit inputs in real-time
     */
    function validateLimitInputs() {
        var hasNegativeValues = false;
        var negativeFields = [];

        $('.limit-input:visible, .total-limit-input:visible').each(function() {
            var $input = $(this);
            var value = parseInt($input.val()) || 0;

            if (value < 0) {
                hasNegativeValues = true;
                negativeFields.push($input);
                $input.addClass('error-field');
                $input.css('border-color', '#dc3232');
            } else {
                $input.removeClass('error-field');
                $input.css('border-color', '');
            }
        });

        return { hasNegativeValues: hasNegativeValues, negativeFields: negativeFields };
    }

    /**
     * Save limits with enhanced validation
     */
    function saveLimits(wildart) {
        var limits = {};
        
        // Validate all inputs first
        var validation = validateLimitInputs();
        
        if (validation.hasNegativeValues) {
            var fieldCount = validation.negativeFields.length;
            showNotification('Fehler: ' + fieldCount + ' Feld(er) enthalten negative Werte. Bitte korrigieren Sie diese vor dem Speichern.', 'error');
            
            // Focus on first negative field
            if (validation.negativeFields.length > 0) {
                validation.negativeFields[0].focus();
            }
            return false; // Stop saving
        }

        // Collect limits from visible inputs only (based on active mode)
        $('.limit-input:visible, .total-limit-input:visible').each(function () {
            var $input = $(this);
            var meldegruppe = $input.data('meldegruppe') || 'total';
            var kategorie = $input.data('kategorie');
            var value = Math.max(0, parseInt($input.val()) || 0); // Ensure non-negative

            // Handle both meldegruppen-specific and total limits
            if (!limits[meldegruppe]) {
                limits[meldegruppe] = {};
            }
            limits[meldegruppe][kategorie] = value;
        });

        // Debug info
        console.log('Saving limits for ' + wildart + ':', limits);

        var $btn = $('.save-limits-btn[data-wildart="' + wildart + '"]');
        var originalText = $btn.text();
        $btn.prop('disabled', true).text('Speichern...');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_save_limits',
                nonce: ahgmh_admin.nonce,
                wildart: wildart,
                limits: limits
            },
            success: function (response) {
                if (response.success) {
                    showNotification('Limits erfolgreich gespeichert!', 'success');
                    // Clear any error styling
                    $('.limit-input, .total-limit-input').removeClass('error-field').css('border-color', '');
                } else {
                    showNotification('Fehler beim Speichern der Limits: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim Speichern der Limits.', 'error');
            },
            complete: function () {
                $btn.prop('disabled', false).text(originalText);
            }
        });
        
        return true;
    }

    /**
     * Show notification
     */
    function showNotification(message, type) {
        type = type || 'info';

        var notification = $('<div class="ahgmh-notification ahgmh-notification-' + type + '">' + message + '</div>');
        $('body').append(notification);

        setTimeout(function () {
            notification.addClass('show');
        }, 100);

        setTimeout(function () {
            notification.removeClass('show');
            setTimeout(function () {
                notification.remove();
            }, 300);
        }, 3000);
    }

    /**
     * Show undo notification with undo button
     */
    function showUndoNotification(message, logId) {
        // Remove any existing undo notifications
        $('.ahgmh-undo-notification').remove();

        var notification = $('<div class="ahgmh-notification ahgmh-undo-notification ahgmh-notification-success">' +
            message +
            ' <button class="button button-small ahgmh-undo-btn" data-log-id="' + logId + '" style="margin-left: 10px;">Rückgängig machen</button>' +
            '</div>');
        $('body').append(notification);

        setTimeout(function () {
            notification.addClass('show');
        }, 100);

        // Keep undo notification longer (10 seconds)
        setTimeout(function () {
            notification.removeClass('show');
            setTimeout(function () {
                notification.remove();
            }, 300);
        }, 10000);

        // Handle undo button click
        notification.find('.ahgmh-undo-btn').on('click', function() {
            handleUndo(logId);
            notification.remove();
        });
    }

    /**
     * Hide notification
     */
    function hideNotification() {
        $('.ahgmh-notification').removeClass('show');
        setTimeout(function () {
            $('.ahgmh-notification').remove();
        }, 300);
    }

    // Initialize when document is ready
    /**
     * Initialize Obmann Management
     */
    function initObmannManagement() {
        // Check if we're on the obmann management page
        if (!$('#obmann-assignment-form').length) {
            return;
        }

        // Load assignments table on page load
        refreshObmannTable();

        // Form submission
        $('#obmann-assignment-form').on('submit', function (e) {
            e.preventDefault();
            assignObmann();
        });

        // Form reset
        $('#obmann-assignment-form').on('reset', function () {
            $('#meldegruppe').prop('disabled', true).html('<option value="">Erst Wildart auswählen...</option>');
            // Clear edit mode
            clearEditMode();
        });

        // Clear edit mode when wildart changes
        $(document).on('change', '#wildart', function () {
            clearEditMode();
        });

        // Edit assignment buttons (unbind first to prevent duplicates)
        $(document).off('click', '.edit-assignment').on('click', '.edit-assignment', function () {
            var userId = $(this).data('user-id');
            var wildart = $(this).data('wildart');
            var meldegruppe = $(this).data('meldegruppe');

            editAssignment(userId, wildart, meldegruppe);
        });

        // Remove assignment buttons (unbind first to prevent duplicates)
        $(document).off('click', '.remove-assignment').on('click', '.remove-assignment', function () {
            var userId = $(this).data('user-id');
            var wildart = $(this).data('wildart');

            console.log('AHGMH DEBUG: Remove button clicked for userId=' + userId + ', wildart=' + wildart);
            
            if (confirm('Sind Sie sicher, dass Sie diese Zuweisung entfernen möchten?')) {
                removeAssignment(userId, wildart);
            }
        });
    }

    /**
     * Load meldegruppen for selected wildart
     */
    window.loadMeldegruppenForWildart = function (wildart) {
        var $meldegruppenSelect = $('#meldegruppe');

        if (!wildart) {
            $meldegruppenSelect.prop('disabled', true)
                .html('<option value="">Erst Wildart auswählen...</option>');
            return;
        }

        // Show loading
        $meldegruppenSelect.prop('disabled', true)
            .html('<option value="">Laden...</option>');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_get_meldegruppen_for_wildart',
                wildart: wildart,
                nonce: ahgmh_admin.nonce
            },
            success: function (response) {
                if (response.success && response.data.length > 0) {
                    var options = '<option value="">Meldegruppe auswählen...</option>';

                    response.data.forEach(function (meldegruppe) {
                        options += '<option value="' + meldegruppe + '">' + meldegruppe + '</option>';
                    });

                    $meldegruppenSelect.html(options).prop('disabled', false);
                } else {
                    $meldegruppenSelect.html('<option value="">Keine Meldegruppen für diese Wildart gefunden</option>');
                }
            },
            error: function () {
                $meldegruppenSelect.html('<option value="">Fehler beim Laden</option>');
                showNotification('Fehler beim Laden der Meldegruppen', 'error');
            }
        });
    };

    /**
     * Assign obmann to meldegruppe
     */
    function assignObmann() {
        var $form = $('#obmann-assignment-form');
        var $submitBtn = $form.find('button[type="submit"]');
        var originalBtnText = $submitBtn.text();
        var isEditMode = $form.hasClass('edit-mode');
        
        // Disable submit button during processing
        $submitBtn.prop('disabled', true).text(isEditMode ? 'Aktualisiere...' : 'Speichere...');

        var formData = {
            action: 'ahgmh_assign_obmann_meldegruppe',
            user_id: $('#user_id').val(),
            wildart: $('#wildart').val(),
            meldegruppe: $('#meldegruppe').val(),
            nonce: ahgmh_admin.nonce
        };

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: formData,
            success: function (response) {
                if (response.success) {
                    var message = isEditMode ? 'Zuweisung erfolgreich aktualisiert!' : 'Obmann erfolgreich zugewiesen!';
                    showNotification(message, 'success');
                    
                    // Reset form and clear edit mode
                    $('#obmann-assignment-form')[0].reset();
                    $('#meldegruppe').prop('disabled', true).html('<option value="">Erst Wildart auswählen...</option>');
                    clearEditMode();
                    
                    // Refresh table
                    refreshObmannTable();
                } else {
                    var errorMsg = response.data && response.data.message ? response.data.message : (response.data || 'Fehler beim Speichern der Zuweisung');
                    showNotification(errorMsg, 'error');
                }
            },
            error: function () {
                showNotification('Netzwerkfehler beim Speichern der Zuweisung', 'error');
            },
            complete: function () {
                // Re-enable submit button
                $submitBtn.prop('disabled', false);
                if (!$form.hasClass('edit-mode')) {
                    $submitBtn.text('Obmann zuweisen');
                } else {
                    $submitBtn.text('Zuweisung aktualisieren');
                }
            }
        });
    }

    /**
     * Edit assignment
     */
    function editAssignment(userId, wildart, currentMeldegruppe) {
    var userName = $('#obmann-assignments-table').find('tr[data-user-id="' + userId + '"][data-wildart="' + wildart + '"]').find('.column-user strong').text();
    
    // Get formatted wildart display from data attribute
    var $row = $('#obmann-assignments-table').find('tr[data-user-id="' + userId + '"][data-wildart="' + wildart + '"]');
    var displayWildart = $row.data('wildart-display') || wildart.charAt(0).toUpperCase() + wildart.slice(1).replace(/_/g, '');
    
        if (confirm('Möchten Sie diese Zuweisung bearbeiten?\n\nUser: ' + userName + '\nWildart: ' + displayWildart + '\nAktuelle Meldegruppe: ' + currentMeldegruppe)) {
            
            var $form = $('#obmann-assignment-form');
            var $submitBtn = $form.find('button[type="submit"]');
            
            // Clear edit mode first
            clearEditMode();
            
            // Pre-fill the form
            $('#user_id').val(userId);
            $('#wildart').val(wildart);
            
            // Load meldegruppen for selected wildart
            loadMeldegruppenForWildart(wildart);
            
            // Wait for meldegruppen to load, then set current selection
            setTimeout(function () {
                $('#meldegruppe').val(currentMeldegruppe);
                
                // Set form to edit mode
                $form.addClass('edit-mode');
                $form.prepend('<div class="ahgmh-edit-notice"><strong>Bearbeitungsmodus:</strong> Ändern Sie die Meldegruppe und klicken Sie auf "Zuweisung aktualisieren"</div>');
                $submitBtn.text('Zuweisung aktualisieren');
                
                // Scroll to form
                $('html, body').animate({
                    scrollTop: $form.offset().top - 50
                }, 300);
                
            }, 800); // Increased timeout to ensure meldegruppen are loaded
        }
    }

    /**
     * Remove assignment
     */
    function removeAssignment(userId, wildart) {
    console.log('AHGMH DEBUG: removeAssignment called with userId=' + userId + ', wildart=' + wildart);
    
    // Find the button that was clicked to show loading state
    var $button = $('.remove-assignment[data-user-id="' + userId + '"][data-wildart="' + wildart + '"]');
    console.log('AHGMH DEBUG: Found button:', $button.length > 0 ? 'yes' : 'no');
    
    var $buttonIcon = $button.find('i');
    var originalClass = $buttonIcon.attr('class');
    
    // Show loading state
        $button.prop('disabled', true);
        $buttonIcon.attr('class', 'dashicons dashicons-update-alt ahgmh-spinning');
        
        console.log('AHGMH DEBUG: About to send AJAX request');
        
        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_remove_obmann',
                user_id: userId,
                wildart: wildart,
                nonce: ahgmh_admin.nonce
            },
            success: function (response) {
                console.log('AHGMH DEBUG: AJAX success response:', response);
                if (response.success) {
                    showNotification('Zuweisung erfolgreich entfernt!', 'success');
                    
                    // Clear edit mode if we're editing this assignment
                    var $form = $('#obmann-assignment-form');
                    if ($form.hasClass('edit-mode') && $('#user_id').val() == userId && $('#wildart').val() == wildart) {
                        clearEditMode();
                        $form[0].reset();
                        $('#meldegruppe').prop('disabled', true).html('<option value="">Erst Wildart auswählen...</option>');
                    }
                    
                    // Refresh table
                    refreshObmannTable();
                } else {
                    var errorMsg = response.data && response.data.message ? response.data.message : (response.data || 'Fehler beim Entfernen der Zuweisung');
                    showNotification(errorMsg, 'error');
                    
                    // Restore button state on error
                    $button.prop('disabled', false);
                    $buttonIcon.attr('class', originalClass);
                }
            },
            error: function (xhr, status, error) {
                console.log('AHGMH DEBUG: AJAX error:', xhr, status, error);
                showNotification('Netzwerkfehler beim Entfernen der Zuweisung', 'error');
                
                // Restore button state on error
                $button.prop('disabled', false);
                $buttonIcon.attr('class', originalClass);
            }
        });
    }

    /**
     * Clear edit mode visual indicators
     */
    function clearEditMode() {
        var $form = $('#obmann-assignment-form');
        $form.removeClass('edit-mode');
        $form.find('.ahgmh-edit-notice').remove();
        $form.find('button[type="submit"]').text('Obmann zuweisen');
    }

    /**
     * Refresh obmann assignments table
     */
    window.refreshObmannTable = function () {
        var $container = $('#obmann-assignments-table');

        // Clear edit mode when refreshing table
        clearEditMode();

        $container.html('<div class="ahgmh-loading"><span class="spinner is-active"></span> Lade Zuweisungen...</div>');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_get_obmann_assignments',
                nonce: ahgmh_admin.nonce
            },
            success: function (response) {
                if (response.success) {
                    $container.html(response.data.html);
                } else {
                    $container.html('<div class="ahgmh-error">Fehler beim Laden der Zuweisungen</div>');
                }
            },
            error: function () {
                $container.html('<div class="ahgmh-error">Fehler beim Laden der Zuweisungen</div>');
            }
        });
    };

    $(document).ready(function () {
        // Check if ahgmh_admin object is available
        if (typeof ahgmh_admin === 'undefined') {
            return;
        }

        initAdmin();
    });
    
    /**
     * Reset all assignments
     */
    function resetAllAssignments() {
        if (confirm('WARNUNG: Sind Sie sicher, dass Sie ALLE Obmann-Zuweisungen entfernen möchten?\n\nDiese Aktion kann nicht rückgängig gemacht werden.')) {
            $.ajax({
                url: ahgmh_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'ahgmh_reset_all_assignments',
                    nonce: ahgmh_admin.nonce
                },
                success: function (response) {
                    if (response.success) {
                        showNotification(response.data.message, 'success');
                        // Clear form and refresh table
                        $('#obmann-assignment-form')[0].reset();
                        $('#meldegruppe').prop('disabled', true).html('<option value="">Erst Wildart auswählen...</option>');
                        clearEditMode();
                        refreshObmannTable();
                    } else {
                        showNotification(response.data.message || 'Fehler beim Zurücksetzen aller Zuweisungen', 'error');
                    }
                },
                error: function () {
                    showNotification('Netzwerkfehler beim Zurücksetzen', 'error');
                }
            });
        }
    }
    
    // Make resetAllAssignments globally available
    window.resetAllAssignments = resetAllAssignments;

    /**
     * Initialize shortcode copy functionality
     */
    function initShortcodeCopy() {
        $(document).on('click', '.copy-shortcode', function(e) {
            e.preventDefault();
            var $button = $(this);
            var shortcode = $button.data('shortcode');

            if (shortcode) {
                copyToClipboard(shortcode, $button);
            }
        });
    }

    /**
     * Initialize bulk actions functionality
     */
    function initBulkActions() {
        // Select all checkbox handler
        $(document).on('change', '#cb-select-all-1', function() {
            const isChecked = $(this).prop('checked');
            $('.ahgmh-submission-checkbox').prop('checked', isChecked);
            updateBulkActionUI();
        });

        // Individual checkbox handler
        $(document).on('change', '.ahgmh-submission-checkbox', function() {
            updateBulkActionUI();

            // Update select all checkbox state
            const totalCheckboxes = $('.ahgmh-submission-checkbox').length;
            const checkedCheckboxes = $('.ahgmh-submission-checkbox:checked').length;
            $('#cb-select-all-1').prop('checked', totalCheckboxes === checkedCheckboxes && totalCheckboxes > 0);
        });

        // Bulk action apply button handler
        $(document).on('click', '#doaction', function(e) {
            e.preventDefault();

            const action = $('#bulk-action-selector-top').val();
            const selectedIds = getSelectedSubmissionIds();

            if (action === '-1') {
                showNotification('Bitte wählen Sie eine Massenaktion aus.', 'warning');
                return;
            }

            if (selectedIds.length === 0) {
                showNotification('Bitte wählen Sie mindestens eine Meldung aus.', 'warning');
                return;
            }

            switch(action) {
                case 'bulk_delete':
                    handleBulkDelete(selectedIds);
                    break;
                case 'bulk_assign':
                    handleBulkAssign(selectedIds);
                    break;
                default:
                    showNotification('Unbekannte Aktion', 'error');
            }
        });
    }

    /**
     * Copy text to clipboard
     */
    function copyToClipboard(text, $button) {
        // Modern clipboard API
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function() {
                showCopySuccess($button);
            }).catch(function() {
                fallbackCopyToClipboard(text, $button);
            });
        } else {
            fallbackCopyToClipboard(text, $button);
        }
    }

    /**
     * Fallback copy method for older browsers
     */
    function fallbackCopyToClipboard(text, $button) {
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();

        try {
            document.execCommand('copy');
            showCopySuccess($button);
        } catch (err) {
            showNotification('Kopieren fehlgeschlagen', 'error');
        }

        $temp.remove();
    }

    /**
     * Show copy success feedback
     */
    function showCopySuccess($button) {
        var $icon = $button.find('.dashicons');
        var originalClass = $icon.attr('class');

        // Change icon to checkmark
        $icon.removeClass('dashicons-clipboard').addClass('dashicons-yes');
        $button.css('color', '#00a32a');

        // Show notification
        showNotification('Shortcode kopiert!', 'success');

        // Reset after 2 seconds
        setTimeout(function() {
            $icon.attr('class', originalClass);
            $button.css('color', '');
        }, 2000);
    }

    /**
     * Update bulk action UI elements based on selection
     */
    function updateBulkActionUI() {
        const selectedCount = $('.ahgmh-submission-checkbox:checked').length;

        $('#bulk-selected-count').text(selectedCount);

        if (selectedCount > 0) {
            $('.bulk-select-info').show();
            $('#doaction').prop('disabled', false);
        } else {
            $('.bulk-select-info').hide();
            $('#doaction').prop('disabled', true);
        }
    }

    /**
     * Get array of selected submission IDs
     */
    function getSelectedSubmissionIds() {
        const ids = [];
        $('.ahgmh-submission-checkbox:checked').each(function() {
            ids.push(parseInt($(this).val()));
        });
        return ids;
    }

    /**
     * Handle bulk delete action
     */
    function handleBulkDelete(ids) {
        const count = ids.length;

        if (!confirm('Sind Sie sicher, dass Sie ' + count + ' Meldung(en) löschen möchten?\n\nDiese Aktion kann nicht rückgängig gemacht werden.')) {
            return;
        }

        // Show loading state
        const $button = $('#doaction');
        const originalText = $button.text();
        $button.prop('disabled', true).text('Lösche...');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_bulk_delete',
                nonce: ahgmh_admin.nonce,
                record_ids: ids,
                confirm_token: 'confirm_bulk_delete'
            },
            success: function(response) {
                if (response.success) {
                    // Show undo notification with undo button
                    if (response.data.log_id) {
                        showUndoNotification(response.data.deleted_count + ' Meldung(en) erfolgreich gelöscht!', response.data.log_id);
                    } else {
                        showNotification(response.data.deleted_count + ' Meldung(en) erfolgreich gelöscht!', 'success');
                    }

                    // Remove deleted rows from table
                    ids.forEach(function(id) {
                        $('input[value="' + id + '"].ahgmh-submission-checkbox').closest('tr').fadeOut(300, function() {
                            $(this).remove();

                            // Check if table is empty
                            if ($('.ahgmh-submission-checkbox').length === 0) {
                                location.reload();
                            }
                        });
                    });

                    // Reset UI
                    $('#cb-select-all-1').prop('checked', false);
                    updateBulkActionUI();
                } else {
                    showNotification('Fehler beim Löschen: ' + (response.data.message || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function() {
                showNotification('Netzwerkfehler beim Löschen', 'error');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    }

    /**
     * Handle bulk assign action
     */
    function handleBulkAssign(ids) {
        const count = ids.length;

        // Check if jagdbezirke data is available
        if (typeof ahgmh_jagdbezirke === 'undefined' || !ahgmh_jagdbezirke || ahgmh_jagdbezirke.length === 0) {
            showNotification('Keine Jagdbezirke verfügbar', 'error');
            return;
        }

        // Create dialog HTML
        const dialogHtml = `
            <div class="ahgmh-bulk-assign-dialog" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
                 background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); z-index: 100000; min-width: 400px;">
                <h3 style="margin-top: 0;">Jagdbezirk zuweisen</h3>
                <p>Wählen Sie einen Jagdbezirk für <strong>${count}</strong> ausgewählte Meldung(en):</p>
                <select id="ahgmh-bulk-assign-jagdbezirk" style="width: 100%; padding: 8px; margin-bottom: 15px;">
                    <option value="">-- Jagdbezirk wählen --</option>
                    ${ahgmh_jagdbezirke.map(jb => '<option value="' + jb + '">' + jb + '</option>').join('')}
                </select>
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" class="button button-secondary ahgmh-cancel-bulk-assign" style="margin-right: 10px;">Abbrechen</button>
                    <button type="button" class="button button-primary ahgmh-confirm-bulk-assign">Zuweisen</button>
                </div>
            </div>
            <div class="ahgmh-bulk-assign-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                 background: rgba(0,0,0,0.5); z-index: 99999;"></div>
        `;

        // Add dialog to page
        $('body').append(dialogHtml);

        // Cancel button handler
        $(document).on('click', '.ahgmh-cancel-bulk-assign, .ahgmh-bulk-assign-overlay', function() {
            $('.ahgmh-bulk-assign-dialog, .ahgmh-bulk-assign-overlay').remove();
        });

        // Confirm button handler
        $(document).on('click', '.ahgmh-confirm-bulk-assign', function() {
            const jagdbezirk = $('#ahgmh-bulk-assign-jagdbezirk').val();

            if (!jagdbezirk) {
                showNotification('Bitte wählen Sie einen Jagdbezirk aus.', 'warning');
                return;
            }

            // Show loading state
            $(this).prop('disabled', true).text('Weise zu...');

            $.ajax({
                url: ahgmh_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'ahgmh_mass_assign',
                    nonce: ahgmh_admin.nonce,
                    record_ids: ids,
                    jagdbezirk: jagdbezirk
                },
                success: function(response) {
                    if (response.success) {
                        // Show undo notification with undo button
                        if (response.data.log_id) {
                            showUndoNotification(response.data.updated_count + ' Meldung(en) erfolgreich zugewiesen!', response.data.log_id);
                        } else {
                            showNotification(response.data.updated_count + ' Meldung(en) erfolgreich zugewiesen!', 'success');
                        }

                        // Close dialog
                        $('.ahgmh-bulk-assign-dialog, .ahgmh-bulk-assign-overlay').remove();

                        // Reload page to show updated data
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showNotification('Fehler bei Zuweisung: ' + (response.data.message || 'Unbekannter Fehler'), 'error');
                        $('.ahgmh-confirm-bulk-assign').prop('disabled', false).text('Zuweisen');
                    }
                },
                error: function() {
                    showNotification('Netzwerkfehler bei Zuweisung', 'error');
                    $('.ahgmh-confirm-bulk-assign').prop('disabled', false).text('Zuweisen');
                }
            });
        });
    }

    /**
     * Handle undo operation
     */
    function handleUndo(logId) {
        if (!confirm('Möchten Sie diese Operation wirklich rückgängig machen?')) {
            return;
        }

        // Show loading notification
        showNotification('Mache rückgängig...', 'info');

        $.ajax({
            url: ahgmh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ahgmh_undo_operation',
                nonce: ahgmh_admin.nonce,
                log_id: logId
            },
            success: function(response) {
                if (response.success) {
                    showNotification(response.data.message, 'success');

                    // Reload page to show restored data
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    showNotification('Fehler beim Rückgängigmachen: ' + (response.data.message || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function() {
                showNotification('Netzwerkfehler beim Rückgängigmachen', 'error');
            }
        });
    }

})(jQuery);
